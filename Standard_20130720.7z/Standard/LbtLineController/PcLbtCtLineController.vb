﻿Imports buhler.Test.Pc.lba
Namespace buhler.Test.pc.Lbt
  Public Class PcLbtCtLineController
    Inherits LineControllerBase
    Public Sub New()
      MyBase.New()
      MessageBox.Show(Str)
    End Sub
  End Class
End Namespace

