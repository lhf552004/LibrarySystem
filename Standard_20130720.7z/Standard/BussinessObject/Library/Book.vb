﻿#Region "Imports"

#End Region
Namespace buhler.lb.bk
  Public Class Book

  End Class
End Namespace

