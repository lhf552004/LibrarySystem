﻿#Region "Imports"
Imports buhler.sql
Imports System.IO
Imports System.Data.SqlClient
Imports buhler.lb.ob
#End Region

#Region "Enum"
Public Enum AdminLevel
  ''' <summary>
  ''' Root 
  ''' </summary>
  ''' <remarks></remarks>
  level0 = 0
  ''' <summary>
  ''' 
  ''' </summary>
  ''' <remarks></remarks>
  level1 = 1
  level2 = 2
  ''' <summary>
  ''' anymous
  ''' </summary>
  ''' <remarks></remarks>
  level3 = 3

End Enum

Public Enum ButtonCategory
  OK = 0
  Cancel = 1

End Enum
#End Region
Namespace buhler.lb.ad

  ''' <summary>
  ''' 管理员类
  ''' </summary>
  ''' <remarks></remarks>
  Public Class administrator
    Inherits ObjBase



    'Public ReadOnly Property ID() As Integer
    '  Get
    '    ID = _id
    '  End Get

    'End Property
#Region "私有成员"
    'Private _id As Integer
    Private Shared _tableName As String = "Administrator"
    'Private Shared _theDatabaseManager As DatabaseManager = DatabaseManager.Instance
    'Private Shared _theAdmins As List(Of Object) = New List(Of Object)
#End Region

    ''' <summary>
    ''' 这个构造函数，获得新的对象，并保存到数据库
    ''' </summary>
    ''' <param name="theName"></param>
    ''' <param name="thePassword"></param>
    ''' <remarks></remarks>
    Public Sub New(ByVal theName As String, ByVal thePassword As String)
      'Dim theAdmis As List(Of Object) = New List(Of Object)
      'Dim ok As Boolean = DatabaseManager.Instance.ReadData("Administrator", "ID", theAdmis)
      Me.Name = theName
      '获得明码
      Me.SetNewDecodedPassword(thePassword)
      Me._flagDecode = True
      Me._flagEncode = False

      '获得明码后，立即加密
      Me._encryypt()

      Dim therow() As String = {Me.Name, Me.GetEncodedPassword}
      Dim err As Exception = Nothing
      Dim ok As Boolean = DatabaseManager.Instance.InsertData(_tableName, therow, err)

      If Not ok Then
        Dim file As New StreamWriter("C:\err.LOG")
        file.WriteLine(err.Message)

      End If

    End Sub
    Protected Sub New()

    End Sub
    '''' <summary>
    '''' 加密标志位
    '''' </summary>
    '''' <remarks></remarks>
    'Private _flagEncode As Boolean
    '''' <summary>
    '''' 解密标志位
    '''' </summary>
    '''' <remarks></remarks>
    'Private _flagDecode As Boolean

    Public Property Level() As AdminLevel
      Get
        Return _level
      End Get
      Set(ByVal value As AdminLevel)
        _level = value
      End Set
    End Property
    Private _level As AdminLevel

    'Public Property Name() As String
    '  Get
    '    Return _name
    '  End Get
    '  Set(ByVal value As String)
    '    _name = value
    '  End Set
    'End Property
    'Private _name As String

    'Public Property Password() As String
    '  Get
    '    Return _password
    '    'Return _decode(_password)
    '  End Get
    '  Set(ByVal value As String)
    '    '_password = _encryypt(value)
    '    _password = value
    '  End Set
    'End Property
    'Private _password As String
    'Private _encodedPassword As String
    'Private _decodedPassword As String

    ''' <summary>
    ''' 获得已加密的密码
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    'Public Function GetEncodedPassword() As String
    '  If _flagEncode Then
    '    Return _encodedPassword
    '  Else
    '    _encryypt()
    '    Return _encodedPassword
    '  End If

    'End Function

    ''' <summary>
    ''' 修改密码
    ''' </summary>
    ''' <param name="thePassword"></param>
    ''' <remarks></remarks>
    'Public Sub SetNewDecodedPassword(ByVal thePassword As String)
    '  _decodedPassword = thePassword
    '  '获得明码后，立即加密
    '  _encryypt()

    'End Sub
    ''' <summary>
    ''' 获得已解密的密码
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    'Public Function GetDecodedPassword() As String
    '  If _flagDecode Then
    '    Return _decodedPassword
    '  Else
    '    _decode()
    '    Return _decodedPassword
    '  End If

    'End Function

    ''' <summary>
    ''' 加密
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    'Private Function _encryypt() As String
    '  _encodedPassword = _decodedPassword
    '  _flagEncode = True
    '  ' to do
    '  Return _encodedPassword

    'End Function

    ''' <summary>
    ''' 解密
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    'Private Function _decode() As String
    '  ' to do
    '  _decodedPassword = _encodedPassword
    '  _flagDecode = True
    '  Return _decodedPassword
    'End Function

    'Public Function UpdateInstance(ByRef err As Exception) As Boolean
    '  UpdateInstance = True
    '  Dim criteria As String = "Name = '" & Me.Name & "'"
    '  err = Nothing
    '  _theDatabaseManager.UpdateData("Administrator", "Password", Me.GetEncodedPassword, criteria, err)
    '  If err IsNot Nothing Then
    '    UpdateInstance = False

    '  End If
    'End Function

    'Public Shared Function GetAllNames(ByRef err As Exception) As List(Of Object)
    '  'Dim err As Exception = Nothing
    '  Dim OK As Boolean = _theDatabaseManager.ReadData(_tableName, "Name", _theAdmins, Nothing, err)
    '  Return _theAdmins
    'End Function

    Public Shared Function GetAllAdminNames(ByRef err As Exception) As List(Of Object)
      GetAllAdminNames = ObjBase.GetAllNames(_tableName, err)
    End Function

    ''' <summary>
    ''' 该方法是获得数据库已存在的对象
    ''' </summary>
    ''' <param name="theName"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Shared Function GetInstance(ByVal theName As String) As administrator
      Dim theReturn As List(Of Object) = New List(Of Object)
      Dim err As Exception = Nothing
      Dim Critera As String = "Name = " & "'" & theName & "'"
      Dim ok As Boolean = DatabaseManager.Instance.ReadData(_tableName, "*", theReturn, Critera, err)
      Dim theAdmin As administrator = Nothing
      If ok Then
        If theReturn.Count = 1 Then
          theAdmin = New administrator()
          theAdmin.Name = theName
          theAdmin._flagDecode = False
          theAdmin._flagEncode = True
          For Each curRow As DataRow In theReturn
            If IsNumeric(curRow.Item("ID")) Then
              theAdmin._id = CInt(curRow.Item("ID"))
            End If
            '获得加密后的密码
            theAdmin._encodedPassword = CStr(curRow.Item("Password"))
            '获得加密后的密码后，立即获得明码

            theAdmin._decode()
          Next
        Else
          'to do
        End If
      Else
        'to do
      End If

      Return theAdmin
    End Function

    Public Overrides Function UpdateInstance(ByRef err As System.Exception) As Boolean
      UpdateInstance = True
      Dim criteria As String = "Name = '" & Me.Name & "'"
      err = Nothing
      _theDatabaseManager.UpdateData("Administrator", "Password", Me.GetEncodedPassword, criteria, err)
      If err IsNot Nothing Then
        UpdateInstance = False

      End If
    End Function



  End Class

  'Public Class Book

  'End Class

  'Public Class Book_HisTory

  'End Class

  'Public Class BS

  'End Class
End Namespace

