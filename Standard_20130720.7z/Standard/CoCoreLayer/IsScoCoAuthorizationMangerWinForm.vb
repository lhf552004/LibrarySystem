﻿Public Class IsScoCoAuthorizationMangerWinForm

End Class
