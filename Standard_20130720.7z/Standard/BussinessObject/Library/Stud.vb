﻿#Region "Imports"

#End Region

Namespace buhler.lb.st

  ''' <summary>
  ''' 
  ''' </summary>
  ''' <remarks></remarks>
  Public Class Student
    Public Property ID() As String
      Get
        Return _id
      End Get
      Set(ByVal value As String)

      End Set
    End Property
    Private _id As String


  End Class
End Namespace