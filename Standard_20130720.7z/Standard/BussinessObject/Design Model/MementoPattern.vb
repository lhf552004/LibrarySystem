﻿
Namespace buhler.Test.DM.MemP
  'Public Class Orginator
  '  Private _state As String = ""
  '  Private Property State() As String
  '    Get
  '      Return _state
  '    End Get
  '    Set(ByVal value As String)
  '      _state = value
  '    End Set
  '  End Property

  '  Public Class 
  '  End Class

End Namespace